const express = require('express'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const DB = path.join(__dirname, 'data', 'db.json');
const ADMIN = { id: (process.env.ADMIN_ID || 'ADMIN001').toUpperCase(), name: process.env.ADMIN_NAME || 'Administrator' };
const ROLES = ["Junior Statistical Officer (JSO)", "Senior Statistical Officer (SSO)", "Statistical Investigator", "Assistant Director", "Deputy Director", "Director", "Deputy Director General (DDG)", "Additional Director General (ADG)", "Director General (DG)", "Indian Statistical Service (ISS) Officer", "Subordinate Statistical Service (SSS) Officer", "Household Survey Officer", "Enterprise Survey Officer", "Field Operations Officer", "Economic Statistics Officer", "National Accounts Officer", "Price Statistics Officer", "Social Statistics Officer", "Data/Statistical Analysis Officer", "Research & Analysis Officer"];

if (!fs.existsSync(DB)) { fs.mkdirSync(path.dirname(DB), { recursive: true }); fs.writeFileSync(DB, JSON.stringify({ employees: [], progress: {} })); }
const load = () => JSON.parse(fs.readFileSync(DB, 'utf8'));
const save = d => fs.writeFileSync(DB, JSON.stringify(d, null, 2));

const sessions = new Map(); // token -> { id, admin }
const auth = needAdmin => (req, res, next) => {
  const s = sessions.get((req.headers.authorization || '').replace('Bearer ', ''));
  if (!s) return res.status(401).json({ error: 'Please login again.' });
  if (needAdmin !== s.admin) return res.status(403).json({ error: 'Not allowed.' });
  req.s = s; next();
};

// Login: Employee ID + Name must match a registered employee (or the admin)
app.post('/api/login', (req, res) => {
  const name = String(req.body.name || '').trim().toLowerCase(), id = String(req.body.id || '').trim().toUpperCase();
  const token = crypto.randomBytes(24).toString('hex');
  if (id === ADMIN.id && name === ADMIN.name.toLowerCase()) {
    sessions.set(token, { id, admin: true });
    return res.json({ token, admin: true, user: { name: ADMIN.name, id } });
  }
  const db = load(), e = db.employees.find(x => x.id === id && x.name.toLowerCase() === name);
  if (!e) return res.status(401).json({ error: 'Access denied: Only registered government officers can login. Check your Employee ID and Name.' });
  sessions.set(token, { id, admin: false });
  res.json({ token, admin: false, user: e, progress: db.progress[id] || {} });
});

// Employee progress (competency levels, module progress, completed courses, certificates, scores)
app.put('/api/progress', auth(false), (req, res) => {
  const db = load();
  if (!db.employees.some(x => x.id === req.s.id)) return res.status(401).json({ error: 'Account removed.' });
  const b = req.body || {};
  db.progress[req.s.id] = { role: b.role, cur: b.cur, prog: b.prog, done: b.done, certs: b.certs, scores: b.scores, notes: b.notes };
  save(db); res.json({ ok: true });
});

// Admin: list / add / remove employees
app.get('/api/admin/employees', auth(true), (req, res) => res.json(load().employees));
app.post('/api/admin/employees', auth(true), (req, res) => {
  const b = req.body || {}, name = String(b.name || '').trim(), id = String(b.id || '').trim().toUpperCase();
  if (!name || !id) return res.status(400).json({ error: 'Name and Employee ID are required.' });
  if (!ROLES.includes(b.role)) return res.status(400).json({ error: 'Invalid role.' });
  const db = load();
  if (id === ADMIN.id || db.employees.some(x => x.id === id)) return res.status(409).json({ error: 'Employee ID already exists.' });
  db.employees.push({ id, name, dept: String(b.dept || '').trim() || 'Not assigned', role: b.role, exp: Number(b.exp) || 0 });
  save(db); res.json({ ok: true });
});
app.delete('/api/admin/employees/:id', auth(true), (req, res) => {
  const id = req.params.id.toUpperCase(), db = load(), n = db.employees.length;
  db.employees = db.employees.filter(x => x.id !== id);
  if (db.employees.length === n) return res.status(404).json({ error: 'Employee not found.' });
  delete db.progress[id]; save(db);
  for (const [t, s] of sessions) if (s.id === id) sessions.delete(t); // kick out active session
  res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('SkillPath running at http://localhost:' + PORT));
