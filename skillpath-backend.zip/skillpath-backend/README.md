# SkillPath – Competency Based E-Learning Portal

A competency-based learning management system for government statistical officers
(JSO, SSO, Directors, ISS Officers etc.), built as part of a DevOps & Agile
Methodologies coursework project.

## Features
- Employee login (Employee ID + Name verification)
- Role-based competency requirements (20 statistical service roles)
- Competency gap analysis (Required vs Current level)
- AI-style personalized course recommendations based on skill gaps
- Course modules with concepts, YouTube/GeeksforGeeks/PDF references
- Quiz-based assessment with scoring, retries, and answer review
- Auto-generated completion certificates
- Admin panel: onboard new employees, revoke access on resignation
- Progress persisted server-side (Node.js + Express + JSON datastore)

## Tech Stack
- Frontend: HTML, CSS, vanilla JavaScript (SPA, no framework)
- Backend: Node.js, Express.js
- Data store: JSON file (data/db.json) — swap for MongoDB/PostgreSQL in production
- DevOps: Docker, GitHub Actions CI pipeline

## Run locally
```
npm install
npm start
```
Visit http://localhost:3000

## Run with Docker
```
docker build -t skillpath-lms .
docker run -p 3000:3000 skillpath-lms
```

## CI/CD
`.github/workflows/ci.yml` runs on every push to `main`:
installs dependencies, smoke-tests the server, and builds the Docker image.

## Agile development approach
This project was built iteratively, sprint by sprint, with each sprint adding
one working increment reviewed before the next began:

| Sprint | Increment delivered |
|---|---|
| 1 | Core navigation shell: Home, Profile, Role selection |
| 2 | Competency assessment + gap analysis engine |
| 3 | AI-style course recommendation logic |
| 4 | Course library, module content, quiz engine with scoring |
| 5 | Certificates, progress dashboard, notifications |
| 6 | Role-based access control (Employee ID + Name login) |
| 7 | Role dataset expanded to 20 statistical service designations |
| 8 | Per-employee experience, role-specific quiz question bank |
| 9 | Module-wise concepts + external reference links (YouTube/GFG/PDF) |
| 10 | Administrator role: onboard / offboard employees |
| 11 | Backend persistence: progress & certificates survive logout/login |
| 12 | DevOps: Dockerfile + GitHub Actions CI pipeline |

Each sprint's output was demonstrated end-to-end (deployable artifact),
matching Agile's principle of delivering working software frequently.
